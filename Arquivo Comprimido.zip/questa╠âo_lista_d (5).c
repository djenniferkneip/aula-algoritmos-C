#include <stdio.h>

int main(){

// inicialização de variáveis e vetores 
Int i, opção; 

// vetor 3 porque sao 3 números lidos pelo teclado 
//

Int vetor [3];

// entrada dos dados para a inversão 
//

printf(‘ entre com a opção de numero ‘);
Scanf( “%d”, &n) ;
printf(‘entre com os elementos a serem invertidos; ‘);
 
For (i = 0; i < opção , i++ );
scanf(“%d”, &vetor[ i ]);

printf(“a ordem inversa é;  “)

// for para a inversão //

For (i = opção - 1; i >= 0; i  - -) {
	printf(“%d”, vet [ i ] )
}
   
Return 0;

}