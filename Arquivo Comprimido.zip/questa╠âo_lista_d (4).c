#include <stdio.h>

int main(){

// inicialização de variáveis //

    int nnum_1 , num_2 , num_3;
    int media;

    printf("Digite o primeiro numero: ");
    scanf("%d", &num_1);

    printf("Digite o segundo numero: ");
    scanf("%d", &num_2);

    printf("Digite o terceiro numero: ");
    scanf("%d", &num_3);

// Condicional para o numero par //
If num_1 %2 ==0;


    media = (n1 + n2 + n3 / 3 );

    printf("A media e de: %d", media);

    return 0;

}